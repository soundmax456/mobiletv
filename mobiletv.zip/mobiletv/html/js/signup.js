$(document).ready(function(){
var fnamebook = $('#fname');
var numbook = $('#number');
var namebook = $('#dname');
var emailbook = $('#email');
var passbook = $('#password');
var cpassbook = $('#cpassword');

$("#register").click(function(){

	var fname = $("#fname").val();
	var number = $("#number").val();
	var name = $("#dname").val();
	var email = $("#email").val();
	var password = $("#password").val();
	var cpassword = $("#cpassword").val();
	
	if( name =='' || email =='' || password =='' || cpassword =='' || fname =='' || number =='')
		{
			fnamebook.css({"border-color": "#d0190b52", 
			"border-width":"2px", 
			"border-style":"solid",
			"background-image":"url('bad.png')",
			"background-position":"94%",
			"background-repeat":"no-repeat"});
			
			numbook.css({"border-color": "#d0190b52", 
			"border-width":"2px", 
			"border-style":"solid",
			"background-image":"url('bad.png')",
			"background-position":"94%",
			"background-repeat":"no-repeat"});
			
			namebook.css({"border-color": "#d0190b52",
			"border-width":"2px", 
			"border-style":"solid",
			"background-image":"url('bad.png')",
			"background-position":"94%",
			"background-repeat":"no-repeat"});
			
			emailbook.css({"border-color": "#d0190b52", 
			"border-width":"2px", 
			"border-style":"solid",
			"background-image":"url('bad.png')",
			"background-position":"94%",
			"background-repeat":"no-repeat"});
			
			passbook.css({"border-color": "#d0190b52", 
			"border-width":"2px", 
			"border-style":"solid",
			"background-image":"url('bad.png')",
			"background-position":"94%",
			"background-repeat":"no-repeat"});
			
			cpassbook.css({"border-color": "#d0190b52", 
			"border-width":"2px", 
			"border-style":"solid",
			"background-image":"url('bad.png')",
			"background-position":"94%",
			"background-repeat":"no-repeat"});
			swal("Ooops!", "Kindly fill all the fields!", "error");
		}	
	else if((password.length)<6)
		{
		  swal("Ooops!", "Password should not be less than 6 characters.", "error");
		}
		
	else if(!(password).match(cpassword))
		{
		   swal("Ooops!", "Your passwords don't match. Try again.", "error");
		} 
	
	else 
	   {
	     $.post("signup.php",{ name1: name, email1: email, password1:password, fname1:fname, number1:number},
		  function(data) {
		   if(data=='You have successfully registered!')
		   {
			swal("Great!", "You have successfully registered!", "success");
			$("form")[0].reset();
		   }else{
		   swal("Ooops!", data, "error");
		   }
		});
	   }
	
	});

});
