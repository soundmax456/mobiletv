<?php
// Establishing connection with server..
 $connection = mysql_connect("localhost", "root", "ettahdavid12");

// Selecting Database 
 $db = mysql_select_db("freetv", $connection);

//Fetching Values from URL  
$name=$_POST['name1'];
$email=$_POST['email1'];
$password=$_POST['password1'];
$fname=$_POST['fname1'];
$number=$_POST['number1'];
//$password= sha1($_POST['password1']);  // Password Encryption, If you like you can also leave sha1

// check if e-mail address syntax is valid or not
$email = filter_var($email, FILTER_SANITIZE_EMAIL); // sanitizing email(Remove unexpected symbol like <,>,?,#,!, etc.)

if (!filter_var($email, FILTER_VALIDATE_EMAIL))
 {
    echo "Your entered an invalid email";
 }
else
 {
	$result = mysql_query("SELECT * FROM users WHERE username='$name'");
    $data = mysql_num_rows($result);
	        
	if(($data)==0)
      {
		//Insert query 
	   $query = mysql_query("insert into users(username, email, password, number, fname) values ('$name', '$email', '$password', '$number', '$fname')");
		if($query)
		   {
			  echo "You have successfully registered!";
		   }
		else
		   {
			  echo "An error occurred!";   
		   }
	} 
	else
	{
		echo "This username is already registered!";
	}  
 }
 
//connection closed
mysql_close ($connection);
?>
