<!DOCTYPE html>
<html lang="zxx">

<head>
   <meta charset="utf-8">
   <title>About - MobileTVNigeria</title>
   <meta content="" name="description">
   <meta content="" name="author">
   <meta content="" name="keywords">
   <meta content="width=device-width, initial-scale=1, maximum-scale=1" name="viewport">
   <!-- Bootstrap CSS -->
   <link href="css/bootstrap.min.css" rel="stylesheet">
   <!-- font awesome CSS -->
   <link rel="stylesheet" href="font-awesome/css/font-awesome.css">
   <!-- freetv CSS -->
   <link href="css/animated-freetv.css" rel="stylesheet">
   <link href="css/freetv-style.css" rel="stylesheet">
   <link href="css/queries-freetv.css" media="all" rel="stylesheet" type="text/css">
   <link rel="shortcut icon" href="img/favicon.png">

</head>

<body oncontextmenu="return false;">

   <!-- preloader -->
   <div class="preloader">
      <div class="mainpreloader"><span></span>
      </div>
   </div>
   <!-- preloader end -->

   <!-- website -->
   <div id="wraperfreetv">
 
      <!-- section background slider -->
      <section class="bgfreetv" aria-label="section-background">
         <div id="bgslideshow">
            <div class="bgfreetv"><img alt="background" src="img/bg-1.jpg">
            </div>
            <div class="bgfreetv"><img alt="background" src="img/bg-2.jpg">
            </div>
            <div class="bgfreetv"><img alt="background" src="img/bg-3.jpg">
            </div>
         </div>
         <div id="particles"></div>
         <div class="overlay-home noselect"></div>
      </section>
      <!-- section background slider close -->

      <!-- logo -->
      <div id="logo" class="brand-freetv-center noselect animfadeInLeft" data-time="0">
         <a href="home.php"><img alt="background" src="img/logo.png">
         </a>
      </div>
	  <!-- logo -->

	  <!--header -->
      <header>
         <div id="main-menu" class="menu-init">
            <!-- mainmenu start -->
            <nav>
               <ul>
               </ul>
            </nav>
            <!-- mainmenu end -->
         </div>
         <!-- navigation mobile end -->
      </header>
      <!--header end -->
      <div class="nav-top-block"></div>
	  
      <!-- content -->
      <div class="main-content">
         <div class="container-fluid">
            <!-- container -->

            <!-- section begin -->
            <section class="row" aria-label="section-heading">
               <div class="col-md-12 center spacedown">
				  <br>
				  <br>
                  <h2 class="animfadeInDown" data-time="600">About Us</h2>
                  <span class="devider-black animfadeInLeft" data-time="1000"></span>
               </div>
            </section>
            <!-- section end -->

            <!-- section begin -->
            <section class="row spacedown animfadeInUp" data-time="1300">
               <div class="col-md-5 h-about v-align bg-page img-left"></div>
               <div class="col-md-7 h-about v-align bg-page col-xs-12">
                  <div class="min-left p-30px">
                     <h3>Welcome To MobileTVNigeria</h3>
                     <h4 class="latin-font color" style="font-size:15px;">Test Transmission</h4>
                     <p>MobileTVNigeria is a no-data mobile cable TV service. You do not require your Internet subscription to view our channels. We offer you News, Live football, Documentaries, Comedy, Nollywood movies, Series and Movies. This is a test transmission. Please send all your feedbacks and enquiries to <a href="mailto:mobiletvnigeria@gmail.com" style="color:#e89c3f;">mobiletvnigeria@gmail.com</a>. As a new user, please register or log in as an existing user to enjoy our free channels. </p>
                     <div class="btn-home"><a class="" href="home.php" style="cursor:pointer !important;">Return Home</a>
                     </div>
                  </div>
               </div>
            </section>
            <!-- section end -->
            
            <!-- section brands-->
            <section aria-label="section-brand">
               <div id="owl-brand" class="owl-carousel spaceup">
                  <div class="item"><img alt="background" src="img/ourclients/1.png">
                  </div>
                  <div class="item"><img alt="background" src="img/ourclients/2.png">
                  </div>
                  <div class="item"><img alt="background" src="img/ourclients/3.png">
                  </div>
                  <div class="item"><img alt="background" src="img/ourclients/4.png">
                  </div>
                  <div class="item"><img alt="background" src="img/ourclients/5.png">
                  </div>
                  <div class="item"><img alt="background" src="img/ourclients/6.png">
                  </div>
                  <div class="item"><img alt="background" src="img/ourclients/7.png">
                  </div>
               </div>
            </section>
            <!-- section brands end-->
            
         </div>
         <!-- container end -->
      
      </div>
      
      <!-- footer -->
      <div class="subfooter">
                <div class="container">
                    <div class="row">
                        <div class="col-md-6 footer2">
                            &copy; Copyright 2018 - <span class="color">MobileTvNigeria</span>                     
                        </div>
                    </div>
                </div>
      </div>
      <!-- footer end -->

      <!-- ScrolltoTop -->
      <div id="totop"><i class="fa fa-angle-up"></i>
      </div>

   </div>
   <!-- website end -->

   <!-- Plugin JS -->
   <script src="plugin/pluginsfreetv.js" type="text/javascript"></script>
   <script src="plugin/jquery.particleground.js" type="text/javascript"></script>
   <!-- fastresto JS -->
   <script src="js/freetv.js" type="text/javascript"></script>
</body>

</html>
