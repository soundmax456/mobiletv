<?php
include('admin/login.php'); // Includes Login Script

if(isset($_SESSION['admin_user'])){
header("location: admin/dashboard.php");
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="utf-8">
   <title>Welcome To MobileTVNigeria - Admin Login</title>
   <meta content="" name="description">
   <meta content="" name="author">
   <meta content="" name="keywords">
   <meta content="width=device-width, initial-scale=1, maximum-scale=1" name="viewport">
   <!-- Bootstrap CSS -->
   <link href="css/bootstrap.min.css" rel="stylesheet">
   <!-- font awesome CSS -->
   <link rel="stylesheet" href="font-awesome/css/font-awesome.css">
   <!-- freetv CSS -->
   <link href="css/animated-freetv.css" rel="stylesheet">
   <link href="css/freetv-style.css" rel="stylesheet">
   <link href="css/queries-freetv.css" media="all" rel="stylesheet" type="text/css">
   <link rel="stylesheet" href="dist/sweetalert.css">
   <link rel="shortcut icon" href="img/favicon.png">
   <style type="text/css">
	  input:required:invalid:focus, input:invalid:focus {
		background-image: url('bad.png')!important;
		background-position: 94% !important;
		background-repeat: no-repeat !important;
		border: 2px solid #d0190b52 !important;
		-moz-box-shadow: none;
	  }
	  input:required:valid { 
		background-image: url('good.png')!important;
		background-position: 94% !important;
		background-repeat: no-repeat!important;
		border: 2px solid #95b79252 !important;
	  }
	  .error_msg{
		background: #e89c3f5c;
		width: 180px;
		margin: 20px auto 10px auto;
		height: 47px;
		padding: 11px;
		color: #ffffffbf;
		border-radius: 5px;
		border: 2px solid #e89c3f96;
	  }
	</style>
    <script src="dist/sweetalert-dev.js"></script>
</head>

<body oncontextmenu="return false;">

   <!-- preloader -->
   <div class="preloader">
      <div class="mainpreloader"><span></span>
      </div>
   </div>
   <!-- preloader end -->

   <!-- website -->
   <div id="wraperfreetv">

      <!-- section background slider -->
      <section class="bgfreetv" aria-label="section-background">
         <div id="bgslideshow">
            <div class="bgfreetv"><img alt="background" src="img/bg-1.jpg">
            </div>
            <div class="bgfreetv"><img alt="background" src="img/bg-3.jpg">
            </div>
         </div>
         <div id="particles"></div>
         <div class="overlay-home noselect"></div>
      </section>
      <!-- section background slider close -->

      <!-- logo -->
      <div id="logo" class="brand-freetv-center noselect animfadeInLeft" data-time="0">
         <a href="home.php"><img alt="background" src="img/logo.png">
         </a>
      </div>
	  <!-- logo -->

      <!-- content home -->
	  <div class="main-content">
      <div class="container-fluid">
      <section class="contentfreetv noselect" aria-label="section-home">
         <div class="row">
            <!-- row -->
            <div class="col-md-12">
			   <div id="slidertext" class="animfadeInUpBig" data-time="1000">
               <?php echo $error; ?>
               </div>
               <h1 class="animfadeInUpBig" style="text-transform:capitalize;" data-time="1500">Admin<span class="color"> Level</span></h1>
               <div id="slidertext" class="animfadeInUpBig" data-time="3000">
                  <div class="main-text"><span class="color">MobileTVNigeria </span>- No-data Mobile TV</div>
               </div>
               <div class="devider-center animfadeInUpBig" data-time="1700"></div>
               <div class="btn-home animfadeInLeft" data-time="2100"><a class="popup-form link-class" style="text-transform:capitalize;"  href="#signin">Log In</a>
               </div>
            </div>
         </div>
         <!-- row end -->
      </section>
      <!-- content home end -->

      <!-- sign in/up start -->
      <section aria-label="section-reservation">
         <div id="signin" class="gray-popup-block mfp-hide animbounceInDown">
            <div class="devider-doted">
               <div class="col-md-12 m-20px">
                  <h2 class="color">Log In</h2>
                  <div class="devider-black"></div>
               </div>
               <form action="" class="row" id="form1" method="post" name="form1">
                  <input id="personbook" name="username" data-type="text" required placeholder="enter username" type="text"><br>
                  <input id="name" name="password" data-type="password" required placeholder="enter password" type="password"><br>
                  <button class="btn-content" name="submit" type="submit" style="text-transform:capitalize;">Submit</button>
               </form>
            </div>
         </div>
      </section>
      <!-- sign in/up end -->
	  </div>
      </div>
	  <!-- footer -->
      <div class="subfooter">
                <div class="container">
                    <div class="row">
                        <div class="col-md-6 footer">
                            &copy; Copyright 2017 - <span class="color">MobileTVNigeria</span>                     
                        </div>
                    </div>
                </div>
      </div>
      <!-- footer end -->

   </div>
   <!-- website end -->
   <!-- Plugin JS -->
   <script src="plugin/pluginsfreetv.js" type="text/javascript"></script>
   <script src="plugin/jquery.particleground.js" type="text/javascript"></script>
   <!-- fastresto JS -->
   <script src="js/freetv.js" type="text/javascript"></script>
</body>

</html>