<?php
session_start(); // Starting Session
$error=''; // Variable To Store Error Message
if (isset($_POST['submit'])) {
if (empty($_POST['username']) || empty($_POST['password'])) {
$error = "<script>swal(\"Ooops!\", \"Your login details is invalid!\", \"error\");</script>";

}
else
{
include '_inc/dbconn.php';
// Define $username and $password
$username=$_POST['username'];
$password=$_POST['password'];
// To protect MySQL injection for Security purpose
$username = stripslashes($username);
$password = stripslashes($password);
$username = mysql_real_escape_string($username);
$password = mysql_real_escape_string($password);
// SQL query to fetch information of registerd users and finds user match.
$query = mysql_query("select * from users where password='$password' AND username='$username'");
$rows = mysql_num_rows($query);
if ($rows == 1) {
sleep(3);
$_SESSION['login_user']=$username; // Initializing Session
header("location: channels.php"); // Redirecting To Other Page
} else {
$error = "<script>swal(\"Ooops!\", \"Your login details is invalid!\", \"error\");</script>";
}
mysql_close(); // Closing Connection
}
}
?>