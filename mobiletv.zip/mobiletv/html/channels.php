<?php
include('session.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="utf-8">
   <title>Channels - MobileTVNigeria</title>
   <meta content="" name="description">
   <meta content="" name="author">
   <meta content="" name="keywords">
   <meta content="width=device-width, initial-scale=1, maximum-scale=1" name="viewport">
   <!-- Bootstrap CSS -->
   <link href="css/bootstrap.min.css" rel="stylesheet">
   <!-- font awesome CSS -->
   <link rel="stylesheet" href="font-awesome/css/font-awesome.css">
   <!-- freetv CSS -->
   <link href="css/animated-freetv.css" rel="stylesheet">
   <link href="css/freetv-style.css" rel="stylesheet">
   <link href="css/queries-freetv.css" media="all" rel="stylesheet" type="text/css">
   <link rel="shortcut icon" href="img/favicon.png">
   <!-- flowplayer 
   <link rel="stylesheet" href="flowplayer/skin.css">
   <script src="flowplayer/jquery-1.12.4.min.js"></script>
   <script src="flowplayer/flowplayer.min.js"></script>
   <script src="flowplayer/flowplayer.hlsjs.min.js"></script> 
   <script>
   flowplayer(function (api) {
    api.on("load", function (e, api, video) {
      $("#vinfo").text(api.engine.engineName + " engine playing " + video.type);
    }); });
   </script>-->
   <script type="text/javascript" src="js/jquery-1.8.3.js"></script>
   <script type='text/javascript'>//<![CDATA[
	$(window).load(function(){
	$(function () {
		var $element = $('#scrolla');
		setInterval(function () {
			$element.fadeIn(500, function () {
				$element.fadeOut(1000, function () {
					$element.fadeIn(1000)
				});
			});
		}, 2500);
	});
	
	$(function () {
		var $element = $('#scrollb');
		setInterval(function () {
			$element.fadeIn(500, function () {
				$element.fadeOut(1000, function () {
					$element.fadeIn(1000)
				});
			});
		}, 2500);
	});
	});//]]> 

	$(function () {
		var $element = $('#scrollc');
		setInterval(function () {
			$element.fadeIn(500, function () {
				$element.fadeOut(1000, function () {
					$element.fadeIn(1000)
				});
			});
		}, 2500);
	});
	</script>
</head>

<body oncontextmenu="return false;">

   <!-- preloader -->
   <div class="preloader">
      <div class="mainpreloader"><span></span>
      </div>
   </div>
   <!-- preloader end -->

   <!-- website -->
   <div id="wraperfreetv">

      <!-- section background slider -->
      <section class="bgfreetv" aria-label="section-background">
         <div id="bgslideshow">
            <div class="bgfreetv"><img alt="background" src="img/bg-1.jpg">
            </div>
            <div class="bgfreetv"><img alt="background" src="img/bg-2.jpg">
            </div>
            <div class="bgfreetv"><img alt="background" src="img/bg-3.jpg">
            </div>
         </div>
         <div id="particles"></div>
         <div class="overlay-home noselect"></div>
      </section>
      <!-- section background slider close -->

      <!-- logo -->
      <div id="logo" class="brand-freetv-center noselect animfadeInLeft" data-time="0">
         <a href="home.php"><img alt="background" src="img/logo.png">
         </a>
      </div>
	  <!-- logo -->
	  
      <!-- content home -->
      <section class="contentfreetv noselect" aria-label="section-home">
         <div class="row">
            <!-- row -->
            <div class="col-md-12">
               <h1 class="animfadeInUpBig" style="text-transform:capitalize;" data-time="1500">Hi, <span class="color"><?php echo $login_session; ?></span></h1>
               <div id="slidertext" class="animfadeInUpBig" data-time="3000">
                  <div class="main-text">Welcome!</div>
               </div>
               <div class="devider-center animfadeInUpBig" data-time="1700"></div>
               <div class="btn-home animfadeInLeft" data-time="2100"><a class="link-class" style="text-transform:capitalize;"  href="logout.php">Log Out</a>
               </div>
            </div>
         </div>
         <!-- row end -->
      </section>
      <!-- content home end -->

      <!-- section channel -->
      <section aria-label="section-channel">

         <!-- toggle channel -->
         <div class="nav-bottom noselect">
            <div id="opengal">
               <i class="fa fa-angle-up"></i>
               <span>Select Channel</span>
            </div>
         </div>
         <!-- toggle channel end -->

         <!-- channel -->
         <div class="bottom-option noselect">

            <!-- close channel -->
            <div class="nav-bottom-close">
               <span>close</span>
               <i class="fa fa-angle-down"></i>
            </div>
            <!-- close channel end -->

            <!-- main channel -->
            <div id="owl-gal" class="owl-carousel">
			<?php 
				$sqlc="SELECT * FROM channels";
				$resultc=  mysql_query($sqlc) or die(mysql_error());
				while($rwsc=  mysql_fetch_array($resultc)){
					echo'<div class="item">
					  <div class="port">
						 <div class="hovereffect">
							<img class="gray-color" src="img/' . $rwsc[6] . '" alt="channelimage" />
							<div class="overlay">
							   <div class="wrap-overlay"></span>
								  <br>
								  <span id="scrolla"><i class="fa fa-chevron-left" aria-hidden="true"></i></span><span class="price">&nbsp;&nbsp;  ' . $rwsc[1] . ' &nbsp;</span><br><span id="scrollc">slide to change</span><span id="scrollb"><i class="fa fa-chevron-right" aria-hidden="true"></i></span>
							   </div>
							   <a class="info detail-page" href="channel_view.php?id=' . $rwsc[0] . '><i class="fa fa-play" aria-hidden="true"></i>&nbsp; Play</a>
							</div>
						 </div>
					  </div>
				   </div>';}
				?>

            </div>
            <!-- main channel end -->
         </div>
         <!-- channel end -->
      </section>
      <!-- section channel end -->
     <!-- footer
      <div class="subfooter">
                <div class="container">
                    <div class="row">
                        <div class="col-md-6">
                            &copy; Copyright 2017 - <span class="color">MobileTVNigeria</span>                     
                        </div>
                    </div>
                </div>
      </div>
      <!-- footer end -->
   </div>
   <!-- website end -->

   <!-- Plugin JS -->
   <script src="plugin/pluginsfreetv.js" type="text/javascript"></script>
   <script src="plugin/jquery.particleground.js" type="text/javascript"></script>
   <!-- fastresto JS -->
   <script src="js/freetv.js" type="text/javascript"></script>
</body>

</html>