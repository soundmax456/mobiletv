<?php
include('session.php');
include('script.php'); 
?>
<!DOCTYPE html>
<html lang="zxx">

<head>
   <meta charset="utf-8">
   <title>Admin Dashboard - MobileTVNigeria</title>
   <meta content="" name="description">
   <meta content="" name="author">
   <meta content="" name="keywords">
   <meta http-equiv="refresh" content="300" >
   <meta content="width=device-width, initial-scale=1, maximum-scale=1" name="viewport">
   <!-- Bootstrap CSS -->
   <link href="css/bootstrap.min.css" rel="stylesheet">
   <!-- font awesome CSS -->
   <link rel="stylesheet" href="font-awesome/css/font-awesome.css">
   <!-- flowplayer -->
   <link rel="stylesheet" href="flowplayer/skin.css">
   <script src="flowplayer/jquery-1.12.4.min.js"></script>
   <script src="flowplayer/flowplayer.min.js"></script>
   <script src="flowplayer/flowplayer.hlsjs.min.js"></script> 
   <script>
   flowplayer(function (api) {
    api.on("load", function (e, api, video) {
      $("#vinfo").text(api.engine.engineName + " engine playing " + video.type);
    }); });
   </script>
   <!-- freetv CSS -->
   <link href="css/animated-freetv.css" rel="stylesheet">
   <link href="css/freetv-style.css" rel="stylesheet">
   <link href="css/queries-freetv.css" media="all" rel="stylesheet" type="text/css">
   <link rel="stylesheet" href="../dist/sweetalert.css">
   <link rel="shortcut icon" href="img/favicon.png">
   <style type="text/css">
		input:required:invalid:focus, input:invalid:focus {
		background-image: url('bad.png')!important;
		background-position: 94% !important;
		background-repeat: no-repeat !important;
		border: 2px solid #d0190b52 !important;
		-moz-box-shadow: none;
		}
		
		input:required:valid { 
		background-image: url('good.png')!important;
		background-position: 94% !important;
		background-repeat: no-repeat!important;
		border: 2px solid #95b79252 !important;
		}
		
		input:focus{
		outline: none;
		}
		
		.icon_select_mate {
		position: absolute;
		top: 15px;
		right: 1%;
		font-size: 16px;
		height: 22px;
		transition: all 275ms;
		}
		
		.select_mate {
		position: relative;
		outline:none;
		text-align: left;
		border-radius: 5px;
		width: 330px;
		height: 50px;
		margin: 5px auto 5px auto;
		border: 0px;
		font-size: 9pt !important;
		font-weight:300 !important;
		letter-spacing: 0px;
		color:#757575;
		background: rgba(48, 52, 64, 0.8);
		border-radius: 5px 5px 0px 0px;
		transition: all 375ms ease-in-out;
		/* Oculto el elemento select */
		}
		.select_mate select {
		position: absolute;
		overflow: hidden;
		height: 0px;
		opacity: 0;
		z-index: -1;
		}

		.cont_list_select_mate {
		position: relative;
		float: left;
		width: 100%;
		}

		.cont_select_int {
		position: absolute;
		left: 0px;
		top: 0px;
		z-index: 999;
		overflow: hidden;
		height: 0px;
		width: 100%;
		background-color: #2d313c;
		padding: 0px;
		margin-bottom: 0px;
		margin-top: 0px;
		border-radius: 0px 0px 3px 3px;
		box-shadow: 1px 4px 10px -2px rgba(0, 0, 0, 0.2);
		transition: all 375ms ease-in-out;
		}
		.cont_select_int li {
		position: relative;
		float: left;
		width: 100%;
		border-bottom: 1px solid #2d313c;
		background-color: #3e424cf2;
		list-style-type: none;
		padding: 10px 2%;
		margin: 0px;
		transition: all 275ms ease-in-out;
		display: block;
		cursor: pointer;
		}
		.cont_select_int li:last-child {
		border-radius: 3px;
		border-bottom: 0px;
		}
		.cont_select_int li:hover {
		background-color: #2d313c;
		}
		.cont_select_int .active {
		background-color: #3f434e;
		}

		/* etiqueta <p> con la opcion selecionada  */
		.selecionado_opcion {
		padding: 15px 3%;
		width: 100%;
		display: block;
		margin: 0px;
		cursor: pointer;
		}
	</style>
	<script type="text/javascript" src="../js/jquery.min.js"></script>
	<script type="text/javascript" src="js/scripts.js"></script>
    <script src="../dist/sweetalert-dev.js"></script>
	<script>
    window.console = window.console || function(t) {};
    </script>

  
  
   <script>
   if (document.location.search.match(/type=embed/gi)) {
    window.parent.postMessage("resize", "*");
   }
   </script>
</head>

<body>

   <!-- preloader -->
   <div class="preloader">
      <div class="mainpreloader"><span></span>
      </div>
   </div>
   <!-- preloader end -->

   <!-- website -->
   <div id="wraperfreetv">

      <!-- section background -->
      <section class="bgfreetv" aria-label="section-background">
         <div id="bgslideshow">
            <div class="bgfreetv"><img alt="background" src="img/bg-1.jpg">
            </div>
            <div class="bgfreetv"><img alt="background" src="img/bg-2.jpg">
            </div>
            <div class="bgfreetv"><img alt="background" src="img/bg-3.jpg">
            </div>
         </div>
		 <div id="particles"></div>
         <div class="overlay-home noselect"></div>
      </section>
      <!-- section background end -->

      <!-- logo -->
      <div id="logo" class="brand-freetv noselect animfadeInLeft" data-time="0">
         <a href="../admin_login.php"><img alt="background" src="img/logo.png">
         </a>
      </div>

      <!--header -->
      <header>
         <div id="main-menu" class="menu-init">
            <!-- mainmenu start -->
            <nav>
               <ul>
                  <li class="animfadeInRight" data-time="1500"><a class="popup-form link-class" href="#channel">Add Channel</a>
                  </li>
                  <li class="animfadeInRight" data-time="1400"><a href="logout.php">Log Out</a>
                  </li>
               </ul>
            </nav>
            <!-- mainmenu end -->
         </div>
         <!-- navigation mobile -->
         <div class="anim-nav" id="nav-icon">
            <div class="menu-line"></div>
            <div class="menu-line1"></div>
            <div class="menu-line2"></div>
         </div>
         <!-- navigation mobile end -->
      </header>
      <!--header end -->
      <div class="nav-top-block"></div>

      <!-- content -->
      <div class="main-content">
         <div class="container-fluid">
            <!-- container -->

            <!-- section begin -->
            <section class="row" aria-label="section-heading">
               <div class="col-md-12 center spacedown">
                  <h2 class="animfadeInDown" data-time="600">Dashboard</h2>
                  <span class="devider-black animfadeInLeft" data-time="1000"></span>
               </div>
            </section>
            <!-- section end -->

            <!-- section event2 -->
            <section class="row v-align spacedown animfadeInUp" data-time="1300">
               <div class="col-md-12 bg-page" id="refreshed">
                     <!-- title -->
                     
                     <!-- title end -->

                     <!-- channel start -->
                     <?php echo $channels; ?>
                     <!-- channel end -->
					 
                     <!-- channel start
                     <div class="col-md-4">
                        <div class="wrap-events">
                           <a class="detail-page link-class" href="channel_view.php">
                              <img alt="events-img" class="img-responsive" src="img/img-event-1.jpg">
                           </a>
                           <div class="events color">CNN</div>
                           <div class="events-desc">
                              <a class="popup-form" href="#edit-channel"><i class="fa fa-pencil"><span>Edit Channel</span></i></a>&nbsp;&nbsp;
                              <a><i class="fa fa-trash"><span>Remove Channel</span></i></a>
                           </div>
                           <span class="devider-doted-cont left"></span>
                        </div>
                     </div>
					 channel end -->

               </div>
            </section>
            <!-- section event2 end -->

         </div>
         <!-- container end -->
      </div>

      <!-- channel start -->
      <section aria-label="section-channel">
         <div id="channel" class="gray-popup-block mfp-hide animbounceInDown">
            <div class="devider-doted">
               <div class="col-md-12 m-20px">
                  <h2 class="color">Channel Details</h2>
                  <div class="devider-black"></div>
               </div>
               <form action="" class="row" id="form1" method="post" name="form1">
                  <input id="name" name="name" required placeholder="enter channel title" type="text"><br>
                  <input id="mp4" name="mp4" placeholder="enter mp4 format link" type="text"><br>
                  <input id="ogg" name="ogg" placeholder="enter ogg format link" type="text"><br>
                  <input id="webm" name="webm" placeholder="enter m3u8 format link" type="text">
				  <div class="select_mate" data-mate-select="active" >
					<select id="image" name="image" onchange="" onclick="return false;" id="">
						<option value="" disabled >Select Display Image </option>
						<option value="1">Image 1</option>
						<option value="2" >Image 2</option>
						<option value="3">Image 3</option>
					</select>
					<p class="selecionado_opcion"  onclick="open_select(this)" ></p>
						<span onclick="open_select(this)" class="icon_select_mate" >
							<svg fill="#757575" height="20" viewBox="0 0 24 24" width="24" xmlns="http://www.w3.org/2000/svg">
								<path d="M7.41 7.84L12 12.42l4.59-4.58L18 9.25l-6 6-6-6z"/>
								<path d="M0-.75h24v24H0z" fill="none"/>
							</svg>
						</span>
					<div class="cont_list_select_mate">
					    <ul class="cont_select_int"></ul> 
					</div>
				  </div>
				  <script src="js/stopExecutionOnTimeout-b2a7b3fe212eaa732349046d8416e00a9dec26eb7fd347590fbced3ab38af52e.js"></script>
				  <button class="btn-content"  type="button" style="text-transform:capitalize;" id="submit_btn">Submit</button>
               </form>
            </div>
         </div>
		 
         <div id="edit-channel" class="gray-popup-block mfp-hide animbounceInDown">
            <div class="devider-doted">
               <div class="col-md-12 m-20px">
                  <h2 class="color">Edit Channel</h2>
                  <div class="devider-black"></div>
               </div>
               <form action="#" class="row" id="form1" method="post" name="form1">
                  <input id="name" name="name" required placeholder="enter channel title" type="text"><br>
                  <input id="mp4" name="mp4" placeholder="enter mp4 format link" type="text"><br>
                  <input id="ogg" name="ogg" placeholder="enter ogg format link" type="text"><br>
                  <input id="webm" name="webm" placeholder="enter m3u8 format link" type="text">
				  <div class="select_mate" data-mate-select="active" >
					<select id="image" name="image" onchange="" onclick="return false;" id="">
						<option value=""  >Select Display Image </option>
						<option value="1">Image 1</option>
						<option value="2" >Image 2</option>
						<option value="3">Image 3</option>
					</select>
					<p class="selecionado_opcion"  onclick="open_select(this)" ></p>
						<span onclick="open_select(this)" class="icon_select_mate" >
							<svg fill="#757575" height="20" viewBox="0 0 24 24" width="24" xmlns="http://www.w3.org/2000/svg">
								<path d="M7.41 7.84L12 12.42l4.59-4.58L18 9.25l-6 6-6-6z"/>
								<path d="M0-.75h24v24H0z" fill="none"/>
							</svg>
						</span>
					<div class="cont_list_select_mate">
					    <ul class="cont_select_int"> </ul> 
					</div>
				  </div>
				  <script src="js/stopExecutionOnTimeout-b2a7b3fe212eaa732349046d8416e00a9dec26eb7fd347590fbced3ab38af52e.js"></script>
				  <button class="btn-content"  type="button" style="text-transform:capitalize;" id="update_btn">Submit</button>
               </form>
            </div>
         </div>
      </section>
      <!-- channel end -->
	  
      <!-- ScrolltoTop -->
      <div id="totop"><i class="fa fa-angle-up"></i>
      </div>

   </div>
   <!-- website end -->

   <!-- Plugin JS -->
   <script src="plugin/pluginsfreetv.js" type="text/javascript"></script>
   <script src="plugin/jquery.particleground.js" type="text/javascript"></script>
   <!-- freetv JS -->
   <script src="js/freetv.js" type="text/javascript"></script>
   <script >
      window.onload = function(){
  crear_select();
}

var Navegador_ = (window.navigator.userAgent||window.navigator.vendor||window.opera),
		Firfx = /Firefox/i.test(Navegador_),
		Mobile_ = /Android|webOS|iPhone|iPad|iPod|BlackBerry/i.test(Navegador_),
	FirfoxMobile = (Firfx && Mobile_);

var li = new Array();
function crear_select(){
var div_cont_select = document.querySelectorAll("[data-mate-select='active']");
var select_ = '';
for (var e = 0; e < div_cont_select.length; e++) {if (window.CP.shouldStopExecution(2)){break;}
div_cont_select[e].setAttribute('data-indx-select',e);
div_cont_select[e].setAttribute('data-selec-open','false');
var ul_cont = document.querySelectorAll("[data-indx-select='"+e+"'] > .cont_list_select_mate > ul");
 select_ = document.querySelectorAll("[data-indx-select='"+e+"'] >select")[0];
 if (Mobile_ || FirfoxMobile) { 
select_.addEventListener('change', function () {
 _select_option(select_.selectedIndex,e);
});
 }
var select_optiones = select_.options;
document.querySelectorAll("[data-indx-select='"+e+"']  > .selecionado_opcion ")[0].setAttribute('data-n-select',e);
document.querySelectorAll("[data-indx-select='"+e+"']  > .icon_select_mate ")[0].setAttribute('data-n-select',e);
for (var i = 0; i < select_optiones.length; i++) {if (window.CP.shouldStopExecution(1)){break;}
li[i] = document.createElement('li');
if (select_optiones[i].selected == true || select_.value == select_optiones[i].innerHTML ) {
li[i].className = 'active';
document.querySelector("[data-indx-select='"+e+"']  > .selecionado_opcion ").innerHTML = select_optiones[i].innerHTML;
};
li[i].setAttribute('data-index',i);
li[i].setAttribute('data-selec-index',e);
// funcion click al selecionar 
li[i].addEventListener( 'click', function(){  _select_option(this.getAttribute('data-index'),this.getAttribute('data-selec-index')); });

li[i].innerHTML = select_optiones[i].innerHTML;
ul_cont[0].appendChild(li[i]);

    }
window.CP.exitedLoop(1);
; // Fin For select_optiones
  }
window.CP.exitedLoop(2);
; // fin for divs_cont_select
} // Fin Function 



var cont_slc = 0;
function open_select(idx){
var idx1 =  idx.getAttribute('data-n-select');
  var ul_cont_li = document.querySelectorAll("[data-indx-select='"+idx1+"'] .cont_select_int > li");
var hg = 0;
var slect_open = document.querySelectorAll("[data-indx-select='"+idx1+"']")[0].getAttribute('data-selec-open');
var slect_element_open = document.querySelectorAll("[data-indx-select='"+idx1+"'] select")[0];
 if (Mobile_ || FirfoxMobile) { 
  if (window.document.createEvent) { // All
  var evt = window.document.createEvent("MouseEvents");
  evt.initMouseEvent("mousedown", false, true, window, 0, 0, 0, 0, 0, false, false, false, false, 0, null);
	slect_element_open.dispatchEvent(evt);
} else if (slect_element_open.fireEvent) { // IE
  slect_element_open.fireEvent("onmousedown");
}
}else {

  
  for (var i = 0; i < ul_cont_li.length; i++) {if (window.CP.shouldStopExecution(3)){break;}
hg += ul_cont_li[i].offsetHeight;
}
window.CP.exitedLoop(3);
; 
 if (slect_open == 'false') {  
 document.querySelectorAll("[data-indx-select='"+idx1+"']")[0].setAttribute('data-selec-open','true');
 document.querySelectorAll("[data-indx-select='"+idx1+"'] > .cont_list_select_mate > ul")[0].style.height = hg+"px";
 document.querySelectorAll("[data-indx-select='"+idx1+"'] > .icon_select_mate")[0].style.transform = 'rotate(180deg)';
}else{
 document.querySelectorAll("[data-indx-select='"+idx1+"']")[0].setAttribute('data-selec-open','false');
 document.querySelectorAll("[data-indx-select='"+idx1+"'] > .icon_select_mate")[0].style.transform = 'rotate(0deg)';
 document.querySelectorAll("[data-indx-select='"+idx1+"'] > .cont_list_select_mate > ul")[0].style.height = "0px";
 }
}

} // fin function open_select

function salir_select(indx){
var select_ = document.querySelectorAll("[data-indx-select='"+indx+"'] > select")[0];
 document.querySelectorAll("[data-indx-select='"+indx+"'] > .cont_list_select_mate > ul")[0].style.height = "0px";
document.querySelector("[data-indx-select='"+indx+"'] > .icon_select_mate").style.transform = 'rotate(0deg)';
 document.querySelectorAll("[data-indx-select='"+indx+"']")[0].setAttribute('data-selec-open','false');
}


function _select_option(indx,selc){
 if (Mobile_ || FirfoxMobile) { 
selc = selc -1;
}
    var select_ = document.querySelectorAll("[data-indx-select='"+selc+"'] > select")[0];

  var li_s = document.querySelectorAll("[data-indx-select='"+selc+"'] .cont_select_int > li");
  var p_act = document.querySelectorAll("[data-indx-select='"+selc+"'] > .selecionado_opcion")[0].innerHTML = li_s[indx].innerHTML;
var select_optiones = document.querySelectorAll("[data-indx-select='"+selc+"'] > select > option");
for (var i = 0; i < li_s.length; i++) {if (window.CP.shouldStopExecution(4)){break;}
if (li_s[i].className == 'active') {
li_s[i].className = '';
};
li_s[indx].className = 'active';

}
window.CP.exitedLoop(4);
;
select_optiones[indx].selected = true;
  select_.selectedIndex = indx;
  select_.onchange();
  salir_select(selc); 
}
      //# sourceURL=pen.js
    </script>
</body>

</html>