<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="utf-8">
   <title>Welcome To FreeTv - Login</title>
   <meta content="" name="description">
   <meta content="" name="author">
   <meta content="" name="keywords">
   <meta content="width=device-width, initial-scale=1, maximum-scale=1" name="viewport">
   <!-- Bootstrap CSS -->
   <link href="css/bootstrap.min.css" rel="stylesheet">
   <!-- font awesome CSS -->
   <link rel="stylesheet" href="font-awesome/css/font-awesome.css">
   <!-- freetv CSS -->
   <link href="css/animated-freetv.css" rel="stylesheet">
   <link href="css/freetv-style.css" rel="stylesheet">
   <link href="css/queries-freetv.css" media="all" rel="stylesheet" type="text/css">
   <link rel="shortcut icon" href="img/favicon.png">
   <style type="text/css">
	  input:required:invalid:focus, input:invalid:focus {
		background-image: url('bad.png')!important;
		background-position: 94% !important;
		background-repeat: no-repeat !important;
		border: 2px solid #d0190b52 !important;
		-moz-box-shadow: none;
	  }
	  input:required:valid { 
		background-image: url('good.png')!important;
		background-position: 94% !important;
		background-repeat: no-repeat!important;
		border: 2px solid #95b79252 !important;
	  }
	</style>
</head>

<body <!--oncontextmenu="return false;"-->>

   <!-- preloader -->
   <div class="preloader">
      <div class="mainpreloader"><span></span>
      </div>
   </div>
   <!-- preloader end -->

   <!-- website -->
   <div id="wraperfreetv">

      <!-- section background slider -->
      <section class="bgfreetv" aria-label="section-background">
         <div id="bgslideshow">
            <div class="bgfreetv"><img alt="background" src="img/bg-1.jpg">
            </div>
            <div class="bgfreetv"><img alt="background" src="img/bg-3.jpg">
            </div>
         </div>
         <div id="particles"></div>
         <div class="overlay-home noselect"></div>
      </section>
      <!-- section background slider close -->

      <!-- logo -->
      <div id="logo" class="brand-freetv-center noselect animfadeInLeft" data-time="0">
         <a href="index.html"><img alt="background" src="img/logo.png">
         </a>
      </div>
	  <!-- logo -->
	  
	  <!-- content home -->
      <section class="contentfreetv noselect" aria-label="section-home">
         <div class="row">
            <!-- row -->
            <div class="col-md-12">
               <h1 class="animfadeInUpBig" data-time="1500">ERROR 404 NOT FOUND</h1>
               <div class="devider-center animfadeInUpBig" data-time="1700"></div>
               <p class="spaceup animfadeInUpBig" data-time="2100">You may have mis-typed the URL, Or the page has been removed, click on the links below</p>
               <div class="btn-content animfadeInRight" data-time="2400"><a class="link-class" style="text-transform:capitalize;" href="dashboard">Back Home</a>
               </div>
            </div>
         </div>
         <!-- row end -->
      </section>
      <!-- content home end -->

      <!-- sign in/up start -->
      <section aria-label="section-reservation">
         <div id="signin" class="gray-popup-block mfp-hide animbounceInDown">
            <div class="devider-doted">
               <div class="col-md-12 m-20px">
                  <h2 class="color">Log In</h2>
                  <div class="devider-black"></div>
               </div>
               <form action="#" class="row" id="form1" method="post" name="form1">
                  <input id="personbook" name="username" data-type="text" required placeholder="enter username" type="text"><br>
                  <input id="name" name="password" data-type="password" required placeholder="enter password" type="password"><br>
                  <div class="success" id="mail_success">Thank you. Your reservation has been sent.</div>
                  <div class="error" id="mail_failed">Error, email not sent</div>
                  <button class="btn-content" style="text-transform:capitalize;" id="send">Submit</button>
               </form>
            </div>
         </div>
		 <div id="signup" class="gray-popup-block mfp-hide animbounceInDown">
            <div class="devider-doted">
               <div class="col-md-12 m-20px">
                  <h2 class="color">Sign Up</h2>
                  <div class="devider-black"></div>
               </div>
               <form action="#" class="row" id="form2" method="post" name="form2">
                  <input id="hourbook" name="uname" required placeholder="enter username" type="text" maxlength="15" pattern="[a-z]{6,15}" title="Username should only contain lowercase letters and not less than 6 characters. e.g. johnnie"><br>
				  <input id="semail" name="semail" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$" placeholder="enter e-mail" type="text" required title="Input must be an email"><br>
                  <input id="password" name="password" pattern=".{6,}" required placeholder="enter password" type="password" title="Password should not be less than 6 characters." onchange="this.setCustomValidity(this.validity.patternMismatch ? this.title : '');if(this.checkValidity()) form.passwordagain.pattern = this.value;"><br>
                  <input id="again" name="passwordagain" required placeholder="password again" type="password" onchange="this.setCustomValidity(this.validity.patternMismatch ? this.title : '');"><br>
                  <div class="success" id="mail_success">Thank you. Your reservation has been sent.</div>
                  <div class="error" id="mail_failed">Error, email not sent</div>
                  <button class="btn-content" style="text-transform:capitalize;" id="submit">Submit</button>
               </form>
            </div>
         </div>
      </section>
      <!-- sign in/up end -->

   </div>
   <!-- website end -->
   <!-- Plugin JS -->
   <script src="plugin/pluginsfreetv.js" type="text/javascript"></script>
   <script src="plugin/jquery.particleground.js" type="text/javascript"></script>
   <!-- freetv JS -->
   <script src="js/freetv.js" type="text/javascript"></script>
</body>

</html>