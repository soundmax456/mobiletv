<?php
include('session.php');
?>
<?php 
	        $id= $_REQUEST['id'];
			$sql1="SELECT * FROM channels WHERE id='$id'";
			$result1= mysql_query($sql1);
            $rws1= mysql_fetch_array($result1);
            $mp4= $rws1[2];
            $ogg= $rws1[3];
            $webm= $rws1[4];
?>
<div class="white-popup-block">
<div class="flowplayer fixed-controls no-toggle no-time play-button obj"
style="width: 100%;
height: 100%;
margin-left: 0%;
margin-top: 0%;
z-index: 1000;" data-key="$812975748999788" data-live="true" data-share="false" data-ratio="0.5625"  data-logo="">
	<video id="my-video" class="video" poster="img.jpg" autoplay="true" stretch="true">
	  <source src="<?php echo $webm;?>" type="application/x-mpegURL">
	  <img src="img.jpg">
	  Your browser does not support the <video> tag, kindly update or change your browser!
	</video>
</div>
</div>