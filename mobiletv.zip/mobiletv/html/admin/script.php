<?php 
  $conn = mysqli_connect('localhost', 'root', 'ettahdavid12', 'freetv');
  if (!$conn) {
    die('Connection failed ' . mysqli_error($conn));
  }
  if (isset($_POST['save'])) {
    $name = $_POST['name'];
  	$mp4 = $_POST['mp4'];
  	$ogg = $_POST['ogg'];
  	$webm = $_POST['webm'];
  	$image = $_POST['image'];
	
	if ($image == '1'){
		$image1= "user_channel1a.jpg";
		$image2= "user_channel1b.jpg";
	}
	if ($image == '2'){
		$image1= "user_channel2a.jpg";
		$image2= "user_channel2b.jpg";
	}
	if ($image == '3'){
		$image1= "user_channel3a.jpg";
		$image2= "user_channel3b.jpg";
	}
  	$sql = "INSERT INTO channels (title, mp4, ogg, webm, image1, image2) VALUES ('{$name}', '{$mp4}', '{$ogg}', '{$webm}', '{$image1}', '{$image2}')";
  	if (mysqli_query($conn, $sql)) {
		  $id = mysqli_insert_id($conn);
		  $channel = '<div class="wrap-events">
				   <a class="detail-page link-class" href="channel_view.php?id=' . $id . '">
					  <img alt="events-img" class="img-responsive" src="img/' . $image1 . '">
				   </a>
				   <div class="events color">' . $name . '</div>
				   <div class="events-desc">
					  <i class="fa fa-pencil"><span class="edit" style="cursor: pointer;" data-id="' . $id . '">Edit Channel</span></i>&nbsp;&nbsp;
					  <i class="fa fa-trash"><span class="delete" style="cursor: pointer;" data-id="' . $id . '">Remove Channel</span></i>
				   </div>
				   <span class="devider-doted-cont left"></span>
				</div>';
			echo $channel;
		    $success = '<script>swal("Great!", "Channel ' . $name . ' was added successfully!", "success");
			           $("#display_area").load(location.href + " #display_area>*", "");</script>';
		    echo $success;
  	}else {
  	  echo "Error: ". mysqli_error($conn);
  	}
  	exit();
  }

  // delete channel from database
  if (isset($_GET['delete'])) {
  	$id = $_GET['id'];
  	$sql = "DELETE FROM channels WHERE id=" . $id;
  	mysqli_query($conn, $sql);
  	exit();
  }
  if (isset($_POST['update'])) {
	$id = $_POST['id'];
  	$name = $_POST['name'];
  	$mp4 = $_POST['mp4'];
  	$ogg = $_POST['ogg'];
  	$webm = $_POST['webm'];
	
  	$sql = "UPDATE channels SET name='{$name}', mp4='{$mp4}', ogg='{$ogg}', webm='{$webm}' WHERE id=".$id;
  	if (mysqli_query($conn, $sql)) {
  		$id = mysqli_insert_id($conn);
  		$channel = '<div class="wrap-events">
				   <a class="detail-page link-class" href="channel_view.php?id=' . $id . '">
					  <img alt="events-img" class="img-responsive" src="img/' . $image1 . '">
				   </a>
				   <div class="events color">' . $name . '</div>
				   <div class="events-desc">
					  <i class="fa fa-pencil"><span class="edit" style="cursor: pointer;" data-id="' . $id . '">Edit Channel</span></i>&nbsp;&nbsp;
					  <i class="fa fa-trash"><span class="delete" style="cursor: pointer;" data-id="' . $id . '">Remove Channel</span></i>
				   </div>
				   <span class="devider-doted-cont left"></span>
				</div>';
  	  echo $channel;
  	}else {
  	  echo "Error: ". mysqli_error($conn);
  	}
  	exit();
  }

  // Retrieve channels from database
  $sql = "SELECT * FROM channels";
  $result = mysqli_query($conn, $sql);
  $channels = '<div id="display_area" class="row devider-doted-menu p-30px"><h3 class="latin-font center"><font size="5px">Channel List</font></h3>'; 
  while ($row = mysqli_fetch_array($result)) {
  	$channels .= '<div class="col-md-4">
				   <div class="wrap-events">
				   <a class="detail-page link-class" href="channel_view.php?id=' . $row['id'] . '">
					  <img alt="events-img" class="img-responsive" src="img/' . $row['image1'] . '">
				   </a>
				   <div style="display: none;" class="mp4">' . $row['mp4'] . '</div>
				   <div style="display: none;" class="ogg">' . $row['ogg'] . '</div>
				   <div style="display: none;" class="webm">' . $row['webm'] . '</div>
				   <div class="events color">' . $row['title'] . '</div>
				   <div class="events-desc">
					  <a class="edit popup-form" href="#"><i class="fa fa-pencil"><span class="edit" style="cursor: pointer;" data-id="' . $row['id'] . '">Edit Channel</span></i></a>&nbsp;&nbsp;
					  <a><i class="fa fa-trash"><span class="delete" style="cursor: pointer;" data-id="' . $row['id'] . '">Remove Channel</span></i></a>
				   </div>
				   <span class="devider-doted-cont left"></span>
				</div></div>';
  }
  $channels .= '</div>';
?>
