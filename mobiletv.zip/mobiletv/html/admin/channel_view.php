<?php
include('session.php');
?>
<?php 
	        $id= $_REQUEST['id'];
			$sql1="SELECT * FROM channels WHERE id='$id'";
			$result1= mysql_query($sql1);
            $rws1= mysql_fetch_array($result1);
            $mp4= $rws1[2];
            $ogg= $rws1[3];
            $webm= $rws1[4];
?>
<div class="white-popup-block">
	<video id="my-video" class="video" poster="img.jpg" playsinline controls loop autoplay>
	  <source src="<?php echo $mp4;?>" type="video/mp4">
	  <source src="<?php echo $ogg;?>" type="video/ogg">
	  <source src="<?php echo $webm;?>" type="application/x-mpegURL">
	  <img src="img.jpg">
	  Your browser does not support the <video> tag, kindly update or change your browser!
	</video>
</div>