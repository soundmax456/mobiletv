$(document).ready(function(){
  // save channel to database
  $(document).on('click', '#submit_btn', function(){
    var name = $('#name').val();
    var mp4 = $('#mp4').val();
    var ogg = $('#ogg').val();
    var webm = $('#webm').val();
    var image = $('#image').val();
    $.ajax({
      url: 'script.php',
      type: 'POST',
      data: {
        'save': 1,
        'name': name,
        'mp4': mp4,
        'ogg': ogg,
        'webm': webm,
        'image': image,
      },
      success: function(response){
        $('#name').val('');
        $('#mp4').val('');
        $('#ogg').val('');
        $('#webm').val('');
        $('#image').val('');
        $('#display_area').append(response);
      }
    });
  });
  
  // delete from database
  $(document).on('click', '.delete', function(){
	var id = $(this).data('id');
  	$clicked_btn = $(this);
	swal({
	title: "Are you sure?",
	text: "You will not be able to recover this!",
	type: "warning",
	showCancelButton: true,
	confirmButtonColor: "#DD6B55",
	confirmButtonText: "Yes, delete it!",
	closeOnConfirm: false
	},
    function(){
  	$.ajax({
  	  url: 'script.php',
  	  type: 'GET',
  	  data: {
    	'delete': 1,
    	'id': id,
      },
      success: function(response){
        // remove the deleted channel
        $clicked_btn.parent().remove();
        $('#name').val('');
        $('#mp4').val('');
        $('#ogg').val('');
        $('#webm').val('');
        $('#image').val('');
		$("#refreshed").load(location.href + " #refreshed");
		swal("Deleted!", "Channel has been deleted.", "success");
      }
  	});
	});
  });
  var edit_id;
  var $edit_channel;
  
  $(document).on('click', '.edit', function(){
  	edit_id = $(this).data('id');
  	$edit_channel = $(this).parent();
  	// grab the channel to be editted
  	var id = $(this).siblings('.delete').text();
  	var name = $(this).siblings('.events').text();
  	var mp4 = $(this).siblings('.mp4').text();
  	var ogg = $(this).siblings('.ogg').text();
  	var webm = $(this).siblings('.webm').text();
  	// place channel in form
  	$('#name').val(name);
  	$('#mp4').val(mp4);
  	$('#ogg').val(ogg);
  	$('#webm').val(webm);
  	$('#image').val(id);
  });
  
  $(document).on('click', '#update_btn', function(){
	var name = $('#name').val();
    var mp4 = $('#mp4').val();
    var ogg = $('#ogg').val();
    var webm = $('#webm').val();
    var id = $('#image').val();
  	$.ajax({
      url: 'script.php',
      type: 'POST',
      data: {
      	'update': 1,
      	'id': id,
      	'name': name,
        'mp4': mp4,
        'ogg': ogg,
        'webm': webm,
      },
      success: function(response){
		$('#name').val('');
        $('#mp4').val('');
        $('#ogg').val('');
        $('#webm').val('');
        $('#image').val('');
      	$edit_channel.replaceWith(response);
      }
  	});		
  });
});