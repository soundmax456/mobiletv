<?php
// Selecting Database
include '../_inc/dbconn.php';
session_start();// Starting Session
// Storing Session
$user_check=$_SESSION['admin_user'];
// SQL Query To Fetch Complete Information Of User
$ses_sql=mysql_query("select username from admin where username='$user_check'");
$row = mysql_fetch_assoc($ses_sql);
$login_session =$row['username'];
if(!isset($login_session)){
mysql_close(); // Closing Connection
header('Location: ../admin_login.php'); // Redirecting To Home Page
}
?>